<!-- Ajeet Yadav, Yongji Li, Elham Hojati -->
<!-- Texas Tech University -->
<!-- CS 5373 -->
<!-- Computer Science Outreach Website -->
<!-- 04/27/15 -->

<!-- workshop_staff.php-->
<!-- Page which contains information about the workshop to staff -->


<?php include("include/header.php"); ?>
<!-- DO NOT EDIT ABOVE-->
<!-- Start page content here-->

<!DOCTYPE html>
<html lang="en">
<body>

		
	<link href="css/orange.css" type="text/css" rel="stylesheet" media="screen">
	<link href="css/button.css" type="text/css" rel="stylesheet" media="screen">
	<link href="css/wrapper.css" type="text/css" rel="stylesheet" media="screen">

	<p><h2 align="center"> Please select what would you like to do: </h2></p>
	<div class="wrapper">
	<p><a href="" class ="button orange">View Workshop</a> </p>
	<div class="wrapper">
	<p><a href="" class ="button orange">Add Workshop</a> </p>
	<div class="wrapper">
	<p><a href="" class ="button orange">Delete Workshop</a> </p>


</body>
</html>

<!-- End page content here-->
<!-- DO NOT EDIT below-->
<?php include("include/footer.php"); ?> 
