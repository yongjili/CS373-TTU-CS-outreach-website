<!-- Ajeet Yadav, Yongji Li, Elham Hojati -->
<!-- Texas Tech University -->
<!-- CS 5373 -->
<!-- Computer Science Outreach Website -->
<!-- 03/14/15 -->

<?php include("include/header.php"); ?> 
<!-- faq.php-->
<!-- Page which contains information about the frequently asked questions page -->

<!-- DO NOT EDIT ABOVE-->
<!-- Start page content here-->



<!DOCTYPE html>
<html lang="en">
   <head>
      <meta charset="utf-8">
	  <meta http-equiv="X-UA-Compatible" content="IE=edge">
	  <meta name="viewport" content="width=device-width, initial-scale=1">
	  <title>FAQ</title>
	  <link rel="stylesheet" 
	  src="//normalize-css.googlecode.com/svn/trunk/normalize.css"	 
	  href="include/style/bootstrap.css">
 
	  
      <link rel="stylesheet" href="include/style/style.css">   
      <link rel='stylesheet' href='http://fonts.googleapis.com/css?family=Dancing+Script'  type='text/css'>
      <link href='http://fonts.googleapis.com/css?family=Almendra:400,700italic' rel='stylesheet' type='text/css'>
	  
	</head>
	<body>
	   <div class="container">
	      <div class="row">
		     <div class="col-md-12">
			     <hr>
		     </div>
		  </div>
		  
	      
	      <div class="row">
		       <div style="text-align:center;" class="col-md-12">
			       <h1 class="career">FAQ (Frequently Asked Questions)</h1>
		       </div>
		    </div>
	      
		  
		  <div class="row">
		     <div class="col-md-3">
				<img class="img-responsive" src="img/TTUMascot.jpg" alt="mascot" style="padding:10px">
			</div>
			<div class="col-md-9">
			    <h4 style="padding:10px;text-align: justify;">
				What undergraduate degrees in computer science are offered by Texas Tech University?
                </h4>
				<p style="padding:10px;text-align: justify;">
				The following undergraduate degrees in computing are offered by Texas Tech University:<br>
                * Bachelor of Science in Computer Science (Department of Computer Science)<br>
                * Bachelor of Science in Computer Engineering (Department of Electrical & Computer Engineering)<br>
                * Bachelor of Arts in Management Information Systems (Rawls College of Business)
                </p>
				<h4 style="padding:10px;text-align: justify;">
				What is Computer Science?
                </h4>
		     </div>
		  </div>
	      <div class="row">
		    <div class="col-md-12">
	           <p style="padding:10px;text-align: justify;">Computer Science is a field that takes a broad approach to computing. 
			   Computer Science students 
			   acquire deep theoretical and technical knowledge concerning computing hardware and software.
			   They learn to use a variety of operating systems, compilers, and computing languages and they learn
			   to apply these tools in scientific, engineering, and business applications. Computer Science students
			   take courses ranging from computer architecture through software project management. This includes
			   courses in basic programming, data structures, operating systems, artificial intelligence, programming
			   language theory, algorithms, digital systems, networking, graphics, software engineering, and database theory.</p>
			   <h4 style="padding:10px; text-align: justify;">
			   What kind of jobs are Computer Science majors qualified for?</h4>
			   <p style="padding:10px;text-align: justify;">
			   The kinds of jobs our students get in the computing field are as diverse as the applications
			   on which computers are focused. Student's can work for companies as diverse as Lockheed Martin,
			   Wal-Mart, Cisco Systems, and Intel. These companies are engaged in advanced computer utilization,
			   large-scale commercial, retail, & database applications, networking, integrated circuit manufacturing,
			   and process control. You will find our students working for any firm in which computing or networking
			   are essential activities. Examples of such firms are Phillips Petroleum, Exxon Mobil, Nortel, Lucent
			   Technologies, Toshiba, Dow Chemical, Sprint, and Raytheon. These are just a few examples of the companies
			   and fields of work in which our graduates are employed.</p>
			   
			   <h4 style="padding:10px; text-align: justify;">
			   What preparation is required to enter the computer science program at Texas Tech University?</h4>
			   <p style="padding:10px;text-align: justify;">
			   High School seniors need to have a good science and math background including chemistry, physics, 
			   and pre-calculus. All incoming freshman take placement exams in mathematics and chemistry to
			   determine if they are ready for the first courses in these areas: Calculus I and Principles of Chemistry I.
			   Students who do not demonstrate a mastery of high school level mathematics and chemistry may be placed in
			   preparatory courses. These courses do not count towards the computer science degree. There is no placement
			   exam in physics. The only requirement is successful completion of a Physics course in high school.</p>
			   
			   <h4 style="padding:10px; text-align: justify;">What programming experience is expected?</h4>
			   <p style="padding:10px;text-align: justify;">
			   Students planning to enter the Computer Science program at Texas Tech University should take
			   a programming course if it is available at their high school. Before a computer science student
			   can take the first Computer Science course, that student must be eligible to enroll in Calculus I
			   and must be familiar with the basics of a least one programming language. If a student has no
			   programming skills, an introductory programming course is offered. This course is not part of
			   the computer science degree plan.</p>
			   
			   <h4 style="padding:10px; text-align: justify;">What fraction of the degree plan consists of computer science courses?</h4>
			   <p style="padding:10px;text-align: justify;">
			   Upon graduation a computer science student will have taken 60 semester hours of computer science courses.
			   One university course is usually 3 semester hours. A total of 123 semester hours is required for graduation
			   from the computer science program.</p>
			   
			   <h4 style="padding:10px; text-align: justify;">What about Transfer Credits?</h4>
			   <p style="padding:10px;text-align: justify;">
			   Many of our students attend junior college before transferring to Texas Tech.
			   The typical junior college transfer student comes to Tech with all or some of the English,
			   history, political science, humanities, chemistry and mathematics requirements completed.
			   Students should be aware that upon graduation, only credits earned at TTU count in the GPA.</p>
			   
			   <h4 style="padding:10px; text-align: justify;">Where can I get more information?</h4>
			   <p style="padding:10px;text-align: justify;">
			   You should contact one of the undergraduate advisors. Their contact information is located on the advising page.</p>
    		</div>
		  </div>
	    <div class="row">
		     <div class="col-md-12">
			     <hr>
		     </div>
		</div>
	
	</div>
	</body>
</html> 


<!-- End page content here-->
<!-- DO NOT EDIT below-->
<?php include("include/footer.php"); ?> 