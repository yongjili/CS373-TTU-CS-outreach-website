<!-- Ajeet Yadav, Yongji Li, Elham Hojati -->
<!-- Texas Tech University -->
<!-- CS 5373 -->
<!-- Computer Science Outreach Website -->
<!-- 03/14/15 -->


<!-- about_us.php-->
<!-- Page which contains information about the developers -->

<?php include("include/header.php"); ?>
<!-- DO NOT EDIT ABOVE-->
<!-- Start page content here-->

<!-- table for each persons info -->
<!DOCTYPE html>
<html>
<body>

<table width="50%" border="0" align="center">
  <tr>
    <td width="130">
    <b><font>Ajeet Yadav</font></b>
    <br />
    <img height="120" width="120" src="img/ajeet.jpg"/>
    </td>
    <td>
    	<p  align="justify">
        	My name is Ajeet Yadav, I was born and raised in Janakpur, a small town located in Southern Nepal. Nepal is a small but beautiful country located in South-East Asia between India and China. I transferred to Texas Tech University in spring 2013 to pursue my undergraduate education. I am pursuing B.S. degree in Computer Science and expecting to graduate in May 2015. My research interests include cyber-	security and security in cloud computing.
    	</p>
      </td>
  </tr>
  <tr>
    <td width="130">
    <b><font>Yongji Li</font></b>
    <br />
    <img height="120" width="120" src="img/yongji.jpg"/>
    </td>
    <td>
    	<p  align="justify">
        	My name is Yongji Li, and I am from Dalian, China. I came to TTU last Fall as a MSSE student and expect to graduate in May 2016. My research interests include website development, mobile software development. My goal is to be a full stack developer in the future.
    	</p>
      </td>
  </tr>
</table>

</body>
</html>

<!-- End page content here-->
<!-- DO NOT EDIT below-->
<?php include("include/footer.php"); ?> 