<!-- Ajeet Yadav, Yongji Li, Elham Hojati -->
<!-- Texas Tech University -->
<!-- CS 5373 -->
<!-- Computer Science Outreach Website -->
<!-- 03/14/15 -->

<!-- redirect.php-->
<!-- Page that displays redirecting information to the users -->

<?php include("include/header.php");?> 
<!-- DO NOT EDIT ABOVE-->
<!-- Start page content here-->
 
<!DOCTYPE html>
<html lang="en">
<body>

		
	<link href="css/orange.css" type="text/css" rel="stylesheet" media="screen">
	<link href="css/button.css" type="text/css" rel="stylesheet" media="screen">
	<link href="css/wrapper.css" type="text/css" rel="stylesheet" media="screen">

	<p><h2 align="center"> You need to be logged in to view this content. </h2></p>
	<div class="wrapper">
	<p><a href="register.php" class ="button orange">Register</a> </p>
	<div class="wrapper">
	<p><a href="login.php" class ="button orange">Login</a> </p>


</body>
</html>


<!-- End page content here-->
<!-- DO NOT EDIT below-->
<?php include("include/footer.php"); ?> 
