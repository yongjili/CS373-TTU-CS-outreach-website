<!-- Ajeet Yadav, Yongji Li, Elham Hojati -->
<!-- Texas Tech University -->
<!-- CS 5373 -->
<!-- Computer Science Outreach Website -->
<!-- 03/14/15 -->

<!-- logout.php-->
<!-- Page that logs the user out -->

<!-- Start session-->
<?php
session_start();
?>

<?php
// remove all session variables
session_unset(); 

// destroy the session 
session_destroy(); 

//send user to login page
header('location:login_page.php');
?>


