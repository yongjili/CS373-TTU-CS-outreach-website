<!-- Ajeet Yadav, Yongji Li, Elham Hojati -->
<!-- Texas Tech University -->
<!-- CS 5373 -->
<!-- Computer Science Outreach Website -->
<!-- 03/14/15 -->


<!-- index.php-->
<!-- The homepage displayed after the user has logged in successfully -->


<?php include("include/header.php"); ?>
<!-- DO NOT EDIT ABOVE-->
<!-- Start page content here-->


<!-- Check if a user is logged in-->
<?php
	
	//if user has not logged in send the user back to the login page
	if($_SESSION["username"] == NULL){
		header('location:login_page.php');
	}
	else {}
?>

<!DOCTYPE html>
<html lang="en">
<body>

<div align="center" >	
<?php
	// Echo session variables that were set on previous page
	 echo "Congratulations. " . $_SESSION["username"] . ",  you have successfully logged in. <br>"
?>
</div>


</body>
</html>

<!-- End page content here-->
<!-- DO NOT EDIT below-->

<?php include("include/footer.php"); ?> 