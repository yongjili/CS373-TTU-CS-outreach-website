<!-- Ajeet Yadav, Yongji Li, Elham Hojati -->
<!-- Texas Tech University -->
<!-- CS 5373 -->
<!-- Computer Science Outreach Website -->
<!-- 03/14/15 -->


<!-- register_student.php-->
<!-- Page to register new students -->

<?php include("include/header.php"); ?>
<!-- DO NOT EDIT ABOVE-->
<!-- Start page content here-->

<!DOCTYPE html>
<html>
<body>

	<!-- includes for all css files-->
		
	<link href="css/orange.css" type="text/css" rel="stylesheet" media="screen">
	<link href="css/button.css" type="text/css" rel="stylesheet" media="screen">
	<link href="css/wrapper.css" type="text/css" rel="stylesheet" media="screen">
	
	<form name="register" method="post" style="text-align:center" action= "register_connect.php" " />
	
	<style>
			p {color:black; }
			ul {
    				list-style-type: none;
    				margin: 0;
    				padding: 0;
			   }
  			body {background-color:white}
  			h1   {text-align: center;color:black}
			h2   {text-align: center;color:black}
 		 	p    {text-align: center;color:black}
	</style>

	<ul>
  	<li> <h2> Registration Form </h2>
  	<p>First Name: 
    	<input name="firstname" type="text" id="firstname" maxlength="30" class ="button orange" placeholder="Enter Your First Name" required /><font color="#FF0000"> *</font> </p>

	<p>Last Name: 
    	<input name="lastname" type="text" id="lastname" maxlength="30" class ="button orange" placeholder="Enter Your Last Name" required /><font color="#FF0000"> *</font> </p>

	<p>Street &nbsp;&nbsp&nbsp;&nbsp&nbsp;: 
    	<input name="street" type="text" id="street" maxlength="30" class ="button orange"placeholder="Enter Your Street"/></p>
	
	<p>City &nbsp;&nbsp&nbsp;&nbsp&nbsp;&nbsp;: 
    	<input name="city" type="text" id="city" maxlength="30" class ="button orange" placeholder="Enter Your City"/></font> </p>
	
	<p>State &nbsp;&nbsp&nbsp;&nbsp&nbsp;&nbsp;: 
    	<input name="state" type="state" id="state" maxlength="30" class ="button orange" placeholder="Enter Your State"/></p>
	
	<p>Zip Code &nbsp;&nbsp&nbsp;: 
    	<input name="zip" type="text" id="zip" SIZE="20" minlength="5" MAXLENGTH="9" class ="button orange" placeholder="Enter Your Zip Code" required /><font color="#FF0000"> *</font> </p>

	<p>Email&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:
        <input name="email" type="email" id="email" maxlength="30" class ="button orange" required placeholder="Enter Your Email"/><font color="#FF0000"> *</font></p>	
	
	<p>Username:
    	<input name="username" type="text" id="username" minlength="6" maxlength="30"  class ="button orange" required placeholder="Enter Your Username"/><font color="#FF0000"> *</font> <!-- username--></p>
	
	<p>Password&nbsp;:
        <input name="password" type="password" id="password" minlength="10" maxlength="25" class ="button orange" required pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{6,}" placeholder="Confirm Your Password" /><font color="#FF0000"> *</font><!-- password--></p>
		Please make sure the password has at least one uppercase letter, one lowercase letter and one number.

	<p>Date of Birth&nbsp;&nbsp: 
    	<input name="dateofbirth" type="date" id="dateofbirth" maxlength="30" class ="button orange" required /><font color="#FF0000"> *</font> </p>

	<p><label for="Gender"> Gender&nbsp: </label>
  		<select id="gender" name="gender" class ="button orange">
     			<option value="0">Select Gender</option>
     			<option value="1">Male</option>
     			<option value="2">Female</option>
  	</select></p>
	<p><label for="Category"> Category&nbsp: </label>
  		<select id="category" name="category" class ="button orange">
     			<option value="0">Select Category</option>
     			<option value="1">Student</option>
     			<option value="2">Parents</option>
     			<option value="3">Staff</option>	
  	</select></p>



   	</li>
	</ul>
  	
	
    <p><font color="#FF0000"> * Required Fields</font>
    <br /></p> 
    <p> <input type="submit" name="Submit" value="Create Account" class ="button orange"/></p> <!-- submit-->
    <br />
	</form>
	 	     

</body>
</html>


<!-- End page content here-->
<!-- DO NOT EDIT below-->
<?php include("include/footer.php"); ?> 