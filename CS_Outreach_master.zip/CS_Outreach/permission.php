<!-- Ajeet Yadav, Yongji Li, Elham Hojati -->
<!-- Texas Tech University -->
<!-- CS 5373 -->
<!-- Computer Science Outreach Website -->
<!-- 04/27/15 -->

<!-- permission.php-->
<!-- Page which contains information about the permission form -->


<?php include("include/header.php"); ?>
<!-- DO NOT EDIT ABOVE-->
<!-- Start page content here-->

<!DOCTYPE html>
<html lang="en">
<body>

	<!-- includes for all css files-->
		
	<link href="css/orange.css" type="text/css" rel="stylesheet" media="screen">
	<link href="css/button.css" type="text/css" rel="stylesheet" media="screen">
	<link href="css/wrapper.css" type="text/css" rel="stylesheet" media="screen">
	

	<form name="register" method="post" style="text-align:center" action= "permission_connect.php" />
	
	<style>
			p {color:black; }
			ul {
    				list-style-type: none;
    				margin: 0;
    				padding: 0;
			   }
  			body {background-color:white}
  			h1   {text-align: center;color:black}
			h2   {text-align: center;color:black}
 		 	p    {text-align: center;color:black}
	</style>

	<ul>
  	<li> <h2> Parental Permission Form </h2>

	<p>Camp/Workshop ID: 
    	<input name="campworkshopid" type="text" id="campworkshopid" class ="button orange" placeholder="Enter Camp/Workshop ID" required /><font color="#FF0000"> *</font> </p>
		Please enter either Camp id or workshop id. </br>

  	<p>Student's Name: 
    	<input name="name1" type="text" id="name1" maxlength="50" class ="button orange" placeholder="Enter your child's name" required /><font color="#FF0000"> *</font> </p>

	<p>Student's Email: 
    	<input name="email" type="email" id="email" maxlength="30" class ="button orange" placeholder="Enter your child's email" required /><font color="#FF0000"> *</font> </p>

	<p>Parent's Name:
        <input name="name2" type="text" id="name2" maxlength="30" class ="button orange" required placeholder="Enter Your Name"/><font color="#FF0000"> *</font></p>	
	
	<p>Relationship&nbsp;&nbsp;&nbsp;:
    	<input name="relation" type="text" id="relation" maxlength="30"  class ="button orange" required placeholder="Your Relation to Student"/><font color="#FF0000"> *</font> </p>
	
	<p>Electronic Sign:
    	<input name="sign" type="text" id="sign" maxlength="30"  class ="button orange" required placeholder="Enter Your Full Name"/><font color="#FF0000"> *</font> </p>
	
	<p>Today's Date: 
    	<input name="date" type="date" id="sdate"  class ="button orange" required style="margin-right: 2px; margin-top: 1px" /><font color="#FF0000"> *</font> </p>

	
	<input type="checkbox" name="check" value="check" required> I accept the terms and conditions.</>
   	
   	</li>
	</ul>
  	
	
    <p><font color="#FF0000"> * Required Fields</font>
    <br /></p> 
    <p> <input type="submit" name="Submit" value="Submit" class ="button orange"/></p> <!-- submit-->
    <br />
	</form>



</body>
</html>

<!-- End page content here-->
<!-- DO NOT EDIT below-->
<?php include("include/footer.php"); ?> 