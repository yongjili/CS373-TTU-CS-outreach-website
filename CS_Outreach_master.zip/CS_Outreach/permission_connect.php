<!-- Ajeet Yadav, Yongji Li, Elham Hojati -->
<!-- Texas Tech University -->
<!-- CS 5373 -->
<!-- Computer Science Outreach Website -->
<!-- 04/27/15 -->


<!-- permissionconnect.php-->
<!-- Page that connect to database to store registration information for new users -->

<?php include("include/header.php"); ?>
<!-- DO NOT EDIT ABOVE-->
<!-- Start page content here-->

<?php
	
define('DB_NAME', 'cs');
define('DB_USER', 'root');
define('DB_PASSWORD', '');
define('DB_HOST', 'localhost');
	
$link = mysql_connect(DB_HOST, DB_USER, DB_PASSWORD);
	
if (!$link) {
		die('Could not connect: ' . mysql_error());	
}
	
$db_selected = mysql_select_db(DB_NAME, $link);
	
if (!$db_selected) {
		die('Cannot use ' .DB_NAME. ': '. mysql_error());
}

$value0 = $_POST['campworkshopid'];	
$value1 = $_POST['name1'];
$value2 = $_POST['email'];
$value3 = $_POST['name2'];
$value4 = $_POST['relation'];
$value5 = $_POST['date'];
$value6 = $_POST['sign'];

	
$sql = "INSERT INTO new_permission (campworkshopid, name1, email, name2, relation, date, sign) VALUES ('$value0','$value1','$value2','$value3','$value4','$value5','$value6')";


if (!mysql_query($sql)) {
		die('Error: ' . mysql_error());
}
	
mysql_close();
?>

<div align="center" >	
	 You have registered successfully.
</div>


<!-- End page content here-->
<!-- DO NOT EDIT below-->
<?php include("include/footer.php"); ?> 