<!-- Ajeet Yadav, Yongji Li, Elham Hojati -->
<!-- Texas Tech University -->
<!-- CS 5373 -->
<!-- Computer Science Outreach Website -->
<!-- 03/14/15 -->

<!-- home.php-->
<!-- Page that is displayed as a home page -->


<?php include("include/header.php"); ?>
<!-- DO NOT EDIT ABOVE-->
<!-- Start page content here-->

<!DOCTYPE html>
<html>
<head>
   <title>Bootstrap(Carousel)

   <style type="text/css"> 
	
        a {	a:link { text-decoration: none;color: blue}
���� 		a:active { text-decoration:blink}
���� 		a:hover { text-decoration:underline;color: red} 
���� 		a:visited { text-decoration: none;color: green}
	
	
	} 
	
        </style>
  </title>

<meta charset="utf-8">
	  <meta http-equiv="X-UA-Compatible" content="IE=edge">
	  <meta name="viewport" content="width=device-width, initial-scale=1">
</head>

<body>
<div class="container">


<div class="row">
	<div class="col-md-12">
		<h1 style=" text-align:center;">Computer Science Outreach Website</h1>
    </div>
</div>
<div class="row">
            <div class="col-md-1">
        </div>
    <div class="col-md-10">
		<div id="myCarousel" class="carousel slide">
		   <!-- ��Carousel Indicator�� -->

           <ol class="carousel-indicators">
              <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
              <li data-target="#myCarousel" data-slide-to="1"></li>
              <li data-target="#myCarousel" data-slide-to="2"></li>
            </ol>
		   
		   <!-- ��Carousel inner�� -->
		   <div class="carousel-inner">
			  <div class="item active">
				 <img class="img-responsive" src="homepage/1.jpg" text-align:center alt="First slide">
				 <div class="carousel-caption">
				<p style=" text-align:center;">From here, it's possible.</p>
			  </div>

			  </div>
			  <div class="item">
				 <img class="img-responsive" src="homepage/2.jpg" text-align:center alt="Second slide">
				 <div class="carousel-caption">
				<p style=" text-align:center;">Happy coding!</p>
			  </div>
			  </div>
			  <div class="item">
				 <img class="img-responsive" src="homepage/3.jpg" text-align:center alt="Third slide">
				<div class="carousel-caption">
				<p style=" text-align:center;">Texas Tech Campus</p>
			  </div>
			  </div>
		   </div>
		 
		   
		   <!-- ��Carousel director�� -->
		   <a class="carousel-control left" href="#myCarousel" 
			  data-slide="prev">&lsaquo;</a>
		   <a class="carousel-control right" href="#myCarousel" 
			  data-slide="next">&rsaquo;</a>
			</div> 
        </div>
        <div class="col-md-1">
        </div>
</div>
<div class="row">
    <div class="col-md-3">
	    <img class="img-responsive" src="homepage/little1.jpg" alt="little1" style="padding:10px;text-align: center;">
        <a href="http://today.ttu.edu/" style="padding:60px;text-align: center; font-size:h1;">  News</a>
	</div>
	<div class="col-md-3">
	    <img class="img-responsive" src="homepage/little2.jpg" alt="little2" style="padding:10px;text-align: center">
		<a href="construction.php" style="padding:40px;text-align: center; font-size:h1;">Summer Camp</a>
	
	</div>
	<div class="col-md-3">
	    <img class="img-responsive" src="homepage/little3.jpg" alt="little3" style="padding:10px">
	    <a href="codingcamp.php" style="padding:30px;text-align:center;">Coding Camp</a>
	    </br>
		</br>
		</br>
		</br>
	</div>
	<div class="col-md-3">
	    <img class="img-responsive" src="homepage/little4.jpg" alt="little4" style="padding:10px">
		<a href="career.php" style="padding:50px;text-align:center;font-size:h1;">What is CS?</a>    
	</div>
</div>
	   <div class="row">
		     <div class="col-md-12">
			     <hr>
		     </div>
		</div>
	</div>

</div>
</body>
</html> 



<!-- End page content here-->
<!-- DO NOT EDIT below-->
<?php include("include/footer.php"); ?> 