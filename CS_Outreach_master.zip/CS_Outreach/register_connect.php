<!-- Ajeet Yadav, Yongji Li, Elham Hojati -->
<!-- Texas Tech University -->
<!-- CS 5373 -->
<!-- Computer Science Outreach Website -->
<!-- 03/14/15 -->


<!-- register_connect.php-->
<!-- Page that connect to database to store registration information for new users -->

<?php include("include/header.php"); ?>
<!-- DO NOT EDIT ABOVE-->
<!-- Start page content here-->

<?php
	
define('DB_NAME', 'cs');
define('DB_USER', 'root');
define('DB_PASSWORD', '');
define('DB_HOST', 'localhost');
	
$link = mysql_connect(DB_HOST, DB_USER, DB_PASSWORD);
	
if (!$link) {
		die('Could not connect: ' . mysql_error());	
}
	
$db_selected = mysql_select_db(DB_NAME, $link);
	
if (!$db_selected) {
		die('Cannot use ' .DB_NAME. ': '. mysql_error());
}
	
$value1 = $_POST['firstname'];
$value2 = $_POST['lastname'];
$value3 = $_POST['street'];
$value4 = $_POST['city'];
$value5 = $_POST['state'];
$value6 = $_POST['zip'];
$value7 = $_POST['email'];
$value8 = $_POST['username'];
$value9 = $_POST['password'];
$value10= $_POST['dateofbirth'];
$value11= $_POST['gender'];
$value12= $_POST['category'];

$options = ['cost' => 11,];	
$hash = password_hash($value9, PASSWORD_BCRYPT, $options);

	
$sql = "INSERT INTO new_user (firstname, lastname, street, city, state, zip, email, username, password, dateofbirth, gender, category) VALUES ('$value1','$value2','$value3','$value4','$value5','$value6','$value7','$value8','$hash','$value10','$value11','$value12')";


if (!mysql_query($sql)) {
		die('Error: ' . mysql_error());
}
	
mysql_close();
?>

<!DOCTYPE html>
<html>
<body>

<div align="center" > You have registered successfully. </div>

</body>
</html>


<!-- End page content here-->
<!-- DO NOT EDIT below-->
<?php include("include/footer.php"); ?> 