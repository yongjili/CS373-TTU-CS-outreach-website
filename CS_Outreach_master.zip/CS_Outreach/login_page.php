<!-- Ajeet Yadav, Yongji Li, Elham Hojati -->
<!-- Texas Tech University -->
<!-- CS 5373 -->
<!-- Computer Science Outreach Website -->
<!-- 03/14/15 -->


<!-- login_page.php -->
<!-- Page that is displayed for the user to login -->


<?php include("include/header.php"); ?>
<!-- DO NOT EDIT ABOVE-->
<!-- Start page content here-->

<!DOCTYPE html>
<html>
<body>

	<link href="css/orange.css" type="text/css" rel="stylesheet" media="screen">
	<link href="css/button.css" type="text/css" rel="stylesheet" media="screen">
	<link href="css/wrapper.css" type="text/css" rel="stylesheet" media="screen">

		<style>
  			body {background-color:white}
  			h1   {text-align: center;color:black}
			h2   {text-align: center;color:black}
 		 	p    {text-align: center;color:black}
			ul {
    				list-style-type: none;
    				margin: 0;
    				padding: 0;
			   }
		</style>

	<ul>
  	<li> <h2><br />Login<br /></h2>

	<!-- form for user to put in login  -->
	<form name="login" method="post" action="login.php" /><!-- form to input login info -->
    	
	<p>UserName:
    	<input name="myusername" type="text" id="myusername" class ="button orange" required /><font color="#FF0000"> *</font> </p>
        <p>Password&nbsp;:
        <input name="mypassword" type="password" id="mypassword" class ="button orange" required /><font color="#FF0000"> *</font> </p>
	<p><input type="submit" name="Submit" value="Login" class ="button  orange"/></p> 
	
	<p><font color="#FF0000"> * Required Fields</font> 

	</form>
</body>
</html>


<!-- End page content here-->
<!-- DO NOT EDIT below-->
<?php include("include/footer.php"); ?> 