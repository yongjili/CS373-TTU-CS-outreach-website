<!-- Ajeet Yadav, Yongji Li, Elham Hojati -->
<!-- Texas Tech University -->
<!-- CS 5373 -->
<!-- Computer Science Outreach Website -->
<!-- 03/14/15 -->


<!-- funact.php-->
<!-- Page that displays information about fun activity. -->


<?php include("include/header.php"); ?>
<!-- DO NOT EDIT ABOVE-->
<!-- Start page content here-->


<!DOCTYPE html>
<html lang="en">
   <head>
      <meta charset="utf-8">
	  <meta http-equiv="X-UA-Compatible" content="IE=edge">
	  <meta name="viewport" content="width=device-width, initial-scale=1">
	  <title>WhoisWho</title>
	  <link rel="stylesheet" 
	  src="//normalize-css.googlecode.com/svn/trunk/normalize.css"
	  href="include/style/bootstrap.css">
	  
	<link rel="stylesheet" href="include/style/style.css">   
      	<link rel='stylesheet' href='http://fonts.googleapis.com/css?family=Dancing+Script'  type='text/css'>
      	<link href='http://fonts.googleapis.com/css?family=Almendra:400,700italic' rel='stylesheet' type='text/css'>
	  
	</head>
	<body>
	   <div class="container">
	      <div class="row">
		     <div class="col-md-12">
			     <hr>
		     </div>
		  </div>
		  
	      
	      <div class="row">
		       <div style="text-align:center;" class="col-md-12">
			       <h1 class="career">Join Hour of Code</h1>
		       </div>
		    </div>
	      
		  <div class="row">
		     <div class="col-md-6">
			    <img class="img-responsive" src="img/fun1.jpg" alt="main career" style="padding:10px">
	                    <img class="img-responsive" src="img/fun2.jpg" alt="main career" style="padding:10px">
			</div>
			<div class="col-md-6">
                            <h3 style="padding:10px;text-align: center; font-family: 'Indie Flower', cursive;">Anna and Elsa from 'Frozen'
                </h3>
			    <h4 style="padding:10px;text-align: justify; font-family: 'Indie Flower', cursive;">Hi, young boys and girls, let's try to play a new game called "Code with Anna and Elsa"!                                   Let's use code to join Anna and Elsa as they explore the magic and beauty of ice.<br>
                               You'll create snowflakes and patterns as you ice skate and make a winter wonderland that you can then share with your friends.<br>
                               In the next hour, you're going to learn the basics of how to code. Traditional programming is usually in text, but we'll use Blockly, which uses visual blocks that you can drag and drop to write programs. This is how even university students learn the basics. Under the hood, you're still creating code.<br>
                            A program is a set of instructions that tells a computer what to do. Let's build a code, or a program, that will help Elsa create a simple line. We will use this later to create more complex patterns.   
                           
                </h4>
                 <a href="http://studio.code.org/s/frozen/stage/1/puzzle/1" target="_blank" style="padding:60px;text-align: center;font-family: 'Indie Flower', cursive;"> Have a try!</a>
		     </div>
		  </div>
	      
	    <div class="row">
		     <div class="col-md-12">
			     <hr>
		     </div>
		</div>
	
	</div>
	</body>
</html> 

<!-- End page content here-->
<!-- DO NOT EDIT below-->
<?php include("include/footer.php"); ?> 


