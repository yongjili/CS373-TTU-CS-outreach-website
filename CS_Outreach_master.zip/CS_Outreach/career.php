<!-- Ajeet Yadav, Yongji Li, Elham Hojati -->
<!-- Texas Tech University -->
<!-- CS 5373 -->
<!-- Computer Science Outreach Website -->
<!-- 03/14/15 -->


<!-- career.php-->
<!-- Page that displays information about the career opportunities. -->


<?php include("include/header.php"); ?>
<!-- DO NOT EDIT ABOVE-->
<!-- Start page content here-->


<!DOCTYPE html>
<html lang="en">
   <head>
      <meta charset="utf-8">
	  <meta http-equiv="X-UA-Compatible" content="IE=edge">
	  <meta name="viewport" content="width=device-width, initial-scale=1">
	  <title>WhoisWho</title>
	  <link rel="stylesheet" 
	  src="//normalize-css.googlecode.com/svn/trunk/normalize.css"
	  href="include/style/bootstrap.css">
	  
	<link rel="stylesheet" href="include/style/style.css">   
    <link rel='stylesheet' href='http://fonts.googleapis.com/css?family=Dancing+Script'  type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Almendra:400,700italic' rel='stylesheet' type='text/css'>
	  
	</head>
	<body>
	  	<div class="container">
	      <div class="row">
		     <div class="col-md-12">
			     <hr>
		     </div>
		  </div>
		  
	      
	      <div class="row">
		       <div style="text-align:center;" class="col-md-12">
			       <h1 class="career">Career of Computer Scientist and Software Engineer</h1>
		       </div>
		    </div>
	      
		  
		  <div class="row">
		     <div class="col-md-6">
			    <img class="img-responsive" src="img/career.jpg" alt="main career" style="padding:10px">
				<img class="img-responsive" src="img/career2.jpg" alt="main career2" style="padding:10px">
			</div>
			<div class="col-md-6">
			    <h4 style="padding:10px;text-align: justify;">Computers have become a ubiquitous part of modern life, and new applications are introduced every day. 
				The use of computer technologies is also commonplace in all types of organizations, in academia,
				research, industry, government, private and business organizations.
				As computers become even more pervasive, the potential for computer-related careers will continue to grow and the career paths in 
				computer-related fields will become more diverse.<br>
				The career opportunities for computer science graduates can be classified into seven categories: 
                programming and software development, information systems operation and management, telecommunications
				and networking, computer science research, web and Internet, graphics and multimedia, training and support,
				and computer industry specialists. Some careers require additional formal training or study, and experience working in the field. 
				For example, an MBA degree is helpful to management consultants,
				a course work in biology and biochemistry is needed for bioinformatics specialists,
				and an advanced degree in computer science is usually required for data miners.
                </h4>
		     </div>
		  </div>
	      <div class="row">
		    <div class="col-md-4">
	           <h3 style="padding:10px">Education</h3>
			   <h4 style="padding:10px; text-align: justify;">Most software engineers have a bachelor's degree in computer science or software engineering. 
			   Until recently only computer science degrees were available, but now specific degrees for software engineering exist. 
			   Sometimes an engineer with a bachelor's degree in a related field will pursue a master's degree in software engineering
			   to get a better understanding of working with software.</h4>
    		</div>
		    <div class="col-md-4">
	           <h3 style="padding:10px">Lifestyle</h3>
			   <h4 class="lifestyle" style="padding:10px; text-align: justify;">Software engineering can be one of the most flexible careers,
			   because software engineers can work anywhere where they have computers and access to the Internet.
			   They can work from home, or from the beach if the job allows!<br>
               They usually work 40-hour weeks, but can work longer hours for special jobs or projects on a deadline. 
			   They usually work in teams with other software engineers, scientists, managers, and experts in the business area.
			   The teams can sometimes consist of people in the same building, and sometimes they are spread across the country or the world. 
			   Some software engineers work in an office but others travel to their client's business.</h4>
    		</div>
			<div class="col-md-4">
	           <h3 style="padding:10px">Salary</h3>
			   <h4 style="padding:10px; text-align: justify;">The average annual salary for an entry-level software engineer is $59,588.</h4>
			   <img class="img-respoinsive" src="img/salary.jpg" alt="salary" style="padding:10px">
			   
    		</div>
		  </div>
	    <div class="row">
		     <div class="col-md-12">
			     <hr>
		     </div>
		</div>
	
	</div>
	</body>
</html> 


<!-- End page content here-->
<!-- DO NOT EDIT below-->
<?php include("include/footer.php"); ?> 