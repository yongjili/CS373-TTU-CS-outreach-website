<!-- Ajeet Yadav, Yongji Li, Elham Hojati -->
<!-- Texas Tech University -->
<!-- CS 5373 -->
<!-- Computer Science Outreach Website -->
<!-- 03/14/15 -->


<!-- login.php -->
<!-- Page that connect the user to the database to verify username and password -->

<html>
<head>
<script>
	//alert telling wrong username or password
	function alertpass() {
    	alert("WRONG Username OR Password");
	}
	//sending user back to login page
	function goto(){
		location.href = 'login_page.php';	
	}
</script>
</head>
<body>
	<?php

		$host="localhost"; // Host name 
		$username="root"; // Mysql username 
		$password=""; // Mysql password 
		$db_name="cs"; // Database name 
		$tbl_name="new_user"; // Table name 

		// Connect to server and select databse.
		mysql_connect("$host", "$username", "$password")or die("cannot connect"); 
		mysql_select_db("$db_name")or die("cannot select DB");

		// username and password sent from form 
		$myusername=$_POST['myusername']; 
		$mypassword=$_POST['mypassword']; 


		// To protect MySQL injection (more detail about MySQL injection)
		$username = stripslashes($myusername);
		$password = stripslashes($mypassword);
		$myusername = mysql_real_escape_string($myusername);
		$mypassword = mysql_real_escape_string($mypassword);
		$sql="SELECT * FROM $tbl_name WHERE username='$myusername' ";
		$result=mysql_query($sql);


		$hash = $_POST['password'];

		if (password_verify($mypassword, $hash)) {
    		echo 'Password is valid!';
		} else {
	    echo 'Invalid password.';
		}

			if($result === FALSE) 	{ 
    						die(mysql_error()); 
						}

			while($row = mysql_fetch_array($result))
						{
    						echo $row['FirstName'];
						}

		// Mysql_num_row is counting table row
		$count=mysql_num_rows($result);

		// If result matched $username and $password, table row must be 1 row
		if($count==1){

			// Register $username, $password and redirect to file "home.php"
			// Start the session
			session_start();
			$_SESSION["username"] = $_POST['myusername'];
			header('location:home.php');
		}
		else {
			echo '<script> alertpass(); </script>';
			echo '<script> goto(); </script>';
		}
	?>
    
</body>
</html>
