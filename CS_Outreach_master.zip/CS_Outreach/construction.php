<!-- Ajeet Yadav, Yongji Li, Elham Hojati -->
<!-- Texas Tech University -->
<!-- CS 5373 -->
<!-- Computer Science Outreach Website -->
<!-- 03/14/15 -->

<!-- construction.php-->
<!-- Page which contains information mentioning that the current page is under constructuion -->


<?php include("include/header.php"); ?>
<!-- DO NOT EDIT ABOVE-->
<!-- Start page content here-->

<!DOCTYPE html>
<html lang="en">
<body>

	<img src="img/construction.jpg" align = "center" name="construction" title="This page is under construction." />
	
	<style>
	p {
		color:black;
    	text-align: justify;
	}
	
	</style>
	<p align="justify"> This page is currrently under construction. Please visit us back soon. </p>


</body>
</html>

<!-- End page content here-->
<!-- DO NOT EDIT below-->
<?php include("include/footer.php"); ?> 
