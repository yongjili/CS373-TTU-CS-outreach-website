<!-- Ajeet Yadav, Yongji Li, Elham Hojati -->
<!-- Texas Tech University -->
<!-- CS 5373 -->
<!-- Computer Science Outreach Website -->
<!-- 03/14/15 -->


<!-- codingcamp.php-->
<!-- Page that displays information about the coding camp. -->


<?php include("include/header.php"); ?>
<!-- DO NOT EDIT ABOVE-->
<!-- Start page content here-->


<!DOCTYPE html>
<html lang="en">
   <head>
      <meta charset="utf-8">
	  <meta http-equiv="X-UA-Compatible" content="IE=edge">
	  <meta name="viewport" content="width=device-width, initial-scale=1">
	  <title>WhoisWho</title>
	  <link rel="stylesheet" 
	  src="//normalize-css.googlecode.com/svn/trunk/normalize.css"
	  href="include/style/bootstrap.css">
	  
	<link rel="stylesheet" href="include/style/style.css">   
    <link rel='stylesheet' href='http://fonts.googleapis.com/css?family=Dancing+Script'  type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Almendra:400,700italic' rel='stylesheet' type='text/css'>
	  
	</head>
	<body>
	  	   <div class="container">
	      
	      <div class="row">
		     <div class="col-md-12">
			     <hr>
 		            
		     </div>
		  </div>
		  
	      
	      <div class="row">
		       <div style="text-align:center;" class="col-md-12">
			       <h1 class="career">Coding Camp</h1>
		       </div>
		    </div>
	      <div class="row">
		     <div class="col-md-12">
 		            <img class="img-responsive" src="img/codingcamp.jpg" style="padding:10px">
		     </div>
		  </div>
		  
		  <div class="row">
			<div class="col-md-12">
			    <h3>Dates and Location</h3>
			    <hr>
			    <h4 style="padding:10px;text-align: justify;">
		 		The 2015 Coding Camp will be held July 14-18, 2015 on the main campus of Texas Tech University in Lubbock. 
				<br>Online registration for participants is now open. <br>The program will be announced soon.
                	    </h4>
			    <h3>Overview</h3>
			    <hr>

			    <h4>
				The 2015 Coding Camp will be held July 14-18, 2015 and has the following themes:<br>
				1. Cyber Security Fundamentals<br>
				2. Information and Data Security<br>
				3. Network Security<br>
				4. Software Security<br>
				5. Smart Grid Security<br>
				6. Cyber Evidence and Forensics
			    </h4>
		     </div>
		  </div>
	     

	    <div class="row">
		     <div class="col-md-12">
			     <hr>
		     </div>
		</div>
	
</body>
</html> 


<!-- End page content here-->
<!-- DO NOT EDIT below-->
<?php include("include/footer.php"); ?> 