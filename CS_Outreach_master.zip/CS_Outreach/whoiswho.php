<!-- Ajeet Yadav, Yongji Li, Elham Hojati -->
<!-- Texas Tech University -->
<!-- CS 5373 -->
<!-- Computer Science Outreach Website -->
<!-- 03/14/15 -->


<!-- whoiswho.php-->
<!-- Page that displays a fun activity. -->


<?php include("include/header.php"); ?>
<!-- DO NOT EDIT ABOVE-->
<!-- Start page content here-->


<!DOCTYPE html>
<html lang="en">
   <head>
      <meta charset="utf-8">
	  <meta http-equiv="X-UA-Compatible" content="IE=edge">
	  <meta name="viewport" content="width=device-width, initial-scale=1">
	  <title>WhoisWho</title>
	  <link rel="stylesheet" 
	  src="//normalize-css.googlecode.com/svn/trunk/normalize.css"
	  href="include/style/bootstrap.css">
	  
	<link rel="stylesheet" href="include/style/style.css">   
      	<link rel='stylesheet' href='http://fonts.googleapis.com/css?family=Dancing+Script'  type='text/css'>
      	<link href='http://fonts.googleapis.com/css?family=Almendra:400,700italic' rel='stylesheet' type='text/css'>
	  
	</head>
	<body>
	   <div class="container">
	      <div class="row">
		     <div class="col-md-12">
			     <hr>


				 </div>
		  </div>
		  
	      
	      <div class="row">
		       <div  class="col-md-12">
			       <h1 name="006" id="006" class="career"  style="text-align:center;">Famous Computer Scientists</h1>
				   <p style="text-align:justify;">Computer scientists specialize in the scientific study of computation and computer technology,
				   hardware and software. They work in the field of computer science,
				   i.e. the study of the theoretical and practical aspects of computing and computers. 
				   Computer scientists work alongside with other research professionals like computer programmers,
				   information technology specialists, electrical engineers, etc. in order to develop new computer technology and design hardware and software.
				   Their research helps to improve the performance of existing computer systems.</p>

&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<a href="#001">Bill Gates</a>&nbsp&nbsp
&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<a href="#002">Steve Jobs</a>&nbsp&nbsp
&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<a href="#003">Larry Page</a>&nbsp&nbsp
&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<a href="#004">Sergey Brin</a>&nbsp&nbsp
&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<a href="#005">Mark Zuckberg</a>
		       </div>
		    </div>
	      
		  <div class="row">
		     <div class="col-md-12">
			     <hr>
				 </div>
		  </div>
		  <div class="row">
		     <div name="001" id="001" class="col-md-3">
			    <img class="img-responsive" src="img/whoiswho/1.jpg" alt="main career" style="padding:10px">
			</div>
			<div class="col-md-3">
			    <h4 style="padding:10px;text-align:center;">Who</h4>
				<h4 style="padding:10px;text-align:center;">Bill Gates</h4>
		    </div>
			<div class="col-md-3">
			    <h4 style="padding:10px;text-align:center;">Title</h4>
				<p style="padding:10px;text-align:center;">Microsoft co-chair</p>
		     </div>
            <div class="col-md-3">
			    <h4 style="padding:10px;text-align:center;">Organization</h4>
				<p style="padding:10px;text-align:center;">Microsoft Corporation</p>
				<img class="img-responsive" src="img/whoiswho/1c.jpg" alt="main career" style="padding:10px">
		     </div>			 
		  </div>
		 
		<div class="row">
		       <div  class="col-md-12">
			       <h4 class="Bilgraphy" style="text-align:left;">Biography</h4>
				   <p style="text-align:justify;">William Henry Gates III was born on October 28, 1955, in Seattle, Washington. 
				   He enjoyed playing games with the family and was very competitive. He also loved to read.<br>
                   Gates became interested in computer programming when he was 13, during the era of giant mainframe computers.
				   Gates wrote a tic-tac-toe program using BASIC, one of the first computer languages.
				   Later he created a computer version of Risk, a board game he liked in which the goal is world domination.
				   At Lakeside, Bill met Paul Allen, who shared his interest in computers. At age 17, 
				   Gates and Allen were paid $20,000 for a program called Traf-O-Data that was used to count traffic.<br>
                   In early 1973, Bill Gates served as a congressional page in the U.S. House of Representatives. 
				   He scored 1590 out of 1600 on the SAT and was accepted by Harvard University. Meanwhile, 
				   Paul Allen dropped out of Washington College to work on computers at Honeywell Corporation and convinced 
				   Gates to drop out of Harvard and join him in starting a new software company in Albuquerque, New Mexico.
				   They called it Micro-Soft. This was soon changed to Microsoft, and they moved their company to Bellevue, Washington.<br>
                   In 1980, IBM, one of the largest technology companies of the era, asked Microsoft to write software
				   to run their new personal computer, the IBM PC. Microsoft kept the licensing rights for the operating system (MS-DOS)
				   so that they earned money for every computer sold first by IBM, and later by all the other companies that made
				   PC computers. Microsoft grew quickly from 25 employees in 1978 to over 90,000 today. Over the years, 
				   Microsoft developed many new technologies and some of the world's most popular software and products
				   such as Word and Power Point. Although some have criticized Gates for using questionable business practices,
				   he built Microsoft into one of the largest companies in the world.<br> 
                   Bill Gates is one of the richest men in the world. In 2006, Gates announced that
				   he would cut back his involvement at Microsoft to spend more time on philanthropy and his foundation. 
                   </p>
		       </div>
		    </div>
		<div class="row">
		       <div  class="col-md-12">
			       <h4 class="interview" style="text-align:left;">Interview</h4>
				   <iframe width="640" height="360" src="https://www.youtube.com/embed/wvhW8cp15tk" frameborder="0" allowfullscreen></iframe>
       	    </div>
<div  class="col-md-9">
</div>
<div  class="col-md-3">
<a href="#006" text-align=right>back to top</a>
</div>
		</div>			   




<div class="row">
		     <div class="col-md-12">
			     <hr>
				 </div>
		  </div>
		  <div class="row">
		     <div class="col-md-3">
			    <img name="002" id="002" class="img-responsive" src="img/whoiswho/2.jpg" alt="main career" style="padding:10px">
			</div>
			<div class="col-md-3">
			    <h4 style="padding:10px;text-align:center;">Who</h4>
				<h4 style="padding:10px;text-align:center;">Steve Jobs</h4>
		    </div>
			<div class="col-md-3">
			    <h4 style="padding:10px;text-align:center;">Title</h4>
				<p style="padding:10px;text-align:center;">co-founder and CEO of Apple Inc</p>
		     </div>
            <div class="col-md-3">
			    <h4 style="padding:10px;text-align:center;">Organization</h4>
				<p style="padding:10px;text-align:center;">Apple Inc.</p>
				<img class="img-responsive" src="img/whoiswho/2c.jpg" alt="main career" style="padding:10px">
		     </div>			 
		  </div>
		 
		<div class="row">
		       <div  class="col-md-12">
			       <h4 class="Bilgraphy" style="text-align:left;">Biography</h4>
				   <p style="text-align:justify;">
				   Steven Paul Jobs was born on February 24, 1955, to a pair of graduate students 
				   who gave him up for adoption because their parents did not want them to marry.
				   Steve was adopted at birth by Clara and Paul Jobs. His mother taught him to read before he went to school.
				   Steve and his father would work on electronics in the family garage, taking apart and reassembling televisions,
				   radios and stereos.<br>
                   In elementary school Steve was bored, and he often played pranks. In fourth grade, he was tested and scored 
				   on a high-school sophomore level. He went to Reed College in Oregon, but dropped out after six months.
				   He stayed at Reed and went to some classes that interested him, slept on the floors of friends' rooms,
				   and got meals at a Hare Krishna temple. He later became a Buddhist. Calligraphy was one class that he enjoyed,
				   and he said that it influenced his interest in design and the use of elegant fonts on Apple computers.<br>
                   Describing the first computer terminal he saw, Steve said. "I fell totally in love with it."<br>
                   In 1970, he was introduced to Steve Wozniak by a mutual friend. Even though Wozniak was five years older,
				   they shared a love of electronics, Bob Dylan, and practical jokes. Together they created the Apple I and Apple 
				   II computers. Wozniak was responsible for the electronics, and Steve concentrated on the design. The Apple II
				   was the first personal computer capable of color graphics. Jobs insisted that Apple design both the software and hardware
				   on Apple products. Apple's first logo had a picture of Sir Isaac Newton sitting under an apple tree.
				   Next came the rainbow, striped apple with a bite taken out on the side. The colored stripes represented the fact that
				   the Apple II could create graphics in color. In 1997, it was simplified to a single color that has changed over time.<br>
                   In the early 1980s, Steve visited Xerox PARC. He noticed desktop icons on their computer screens. 
				   Most computers at this time used a text-only interface. Steve made an arrangement with Xerox
				   so he could use their idea of a graphical user interface. He improved it a so computers would be more user-friendly.
				   In 1984, the Macintosh computer was launched with a famous commercial at the Super Bowl.<br>
                   Steve said, "In 1984, Apple introduced the first Macintosh. It didn't just change Apple. It changed
				   the whole computer industry. In 2001, we introduced the first iPod. It didn't just change the way
				   we all listen to music. It changed the entire music industry."<br>
                   In 1986, he bought the computer graphics division of Lucasfilm and started Pixar Animation Studios.
				   Jobs let the animators continue to create the stories, but insisted on attention to detail and design.<br>
                   Steve has been described as brilliant, abrasive, self-centered, a perfectionist and temperamental.
				   He was a technologist and a businessman, but he was also an artist and designer. He was difficult to work for,
				   but most employees were extremely loyal because he knew how to motivate them. Larry Ellison said that
				   Steve combined "obsessiveness with Picasso's aesthetic and Edison's inventiveness."
                   Steve said, "Innovation distinguishes between a leader and a follower."<br>
                   Steve Jobs is listed as the inventor or co-inventor on 342 United States patents.
				   He played a key role in the creation of the Apple II, Macintosh, iMac, MacBook, iPod, iTunes,
				   iPhone, and iPad. He died on Oct. 5, 2011, of complications from pancreatic cancer.

                   </p>
		       </div>
		    </div>
		<div class="row">
		       <div  class="col-md-12">
			       <h4 class="interview" style="text-align:left;">Interview</h4>
				   <p style="text-align:justify;">  
				   <iframe width="640" height="360" src="https://www.youtube.com/embed/QjaTZODOKmw?rel=0" frameborder="0" allowfullscreen></iframe>
		           </p>
       	    </div>
<div  class="col-md-9">
</div>
<div  class="col-md-3">
<a href="#006" text-align=right>back to top</a>
</div>

		</div>	

		<div class="row">
		     <div class="col-md-12">
			     <hr>
				 </div>
		  </div>
		  <div class="row">
		     <div class="col-md-3">
			    <img name="003" id="003" class="img-responsive" src="img/whoiswho/3.jpg" alt="main career" style="padding:10px">
			</div>
			<div class="col-md-3">
			    <h4 style="padding:10px;text-align:center;">Who</h4>
				<h4 style="padding:10px;text-align:center;">Larry Page</h4>
		    </div>
			<div class="col-md-3">
			    <h4 style="padding:10px;text-align:center;">Title</h4>
				<p style="padding:10px;text-align:center;">CEO of Google</p>
		     </div>
            <div class="col-md-3">
			    <h4 style="padding:10px;text-align:center;">Organization</h4>
				<p style="padding:10px;text-align:center;">Google Inc.</p>
				<img class="img-responsive" src="img/whoiswho/3c.jpg" alt="main career" style="padding:10px">
		     </div>			 
		  </div>
		 
		<div class="row">
		       <div  class="col-md-12">
			       <h4 class="Bilgraphy" style="text-align:left;">Biography</h4>
				   <p style="text-align:justify;"> 
				   Larry Page, born as Lawrence Page, is an American entrepreneur and computer scientist who, 
				   along with Sergey Brin, co-founded Google Inc., the search engine giant that offers a wide range
				   of internet products and services. Google began as an online search firm and gradually expanded
				   its operations to other internet related areas. As the son of computer professionals, Page's
				   fascination with computers began at an early age. As a child, he showed keen interest in technology,
				   business and innovation. While studying Computer Science at Stanford University, he met Sergey Brin
				   with whose assistance he created a search engine that returned results based on relevancy.
				   Page and Brin launched the company under the name 'Google Inc' in 1998. They both served as the
				   co-presidents until 2001 when Eric Schmidt was appointed as Chairman and CEO of Google. In 2011,
				   Page officially became the CEO of Google while Schmidt continues to serve as executive chairman.
				   Page is also a member of the Board of Directors of the company. He has an interest in renewable
				   energy technology and philanthropy. Google.org, the philanthropic branch of the company, was set
				   up in 2004. It basically deals with issues of climate change and renewable energy.
                   </p>
		       </div>
		    </div>
		<div class="row">
		       <div  class="col-md-12">
			       <h4 class="interview" style="text-align:left;">Interview</h4>
				   <p style="text-align:justify;">  
				   <iframe width="640" height="360" src="https://www.youtube.com/embed/0vv0NKieCoI?rel=0" frameborder="0" allowfullscreen></iframe>
		           </p>
       	    </div>
<div  class="col-md-9">
</div>
<div  class="col-md-3">
<a href="#006" text-align=right>back to top</a>
</div>
		</div>	




		<div class="row">
		     <div class="col-md-12">
			     <hr>
				 </div>
		  </div>
		  <div class="row">
		     <div class="col-md-3">
			    <img name="004" id="004" class="img-responsive" src="img/whoiswho/4.jpg" alt="main career" style="padding:10px">
			</div>
			<div class="col-md-3">
			    <h4 style="padding:10px;text-align:center;">Who</h4>
				<h4 style="padding:10px;text-align:center;">Sergey Brin</h4>
		    </div>
			<div class="col-md-3">
			    <h4 style="padding:10px;text-align:center;">Title</h4>
				<p style="padding:10px;text-align:center;">Director of Google X and Special Projects</p>
		     </div>
            <div class="col-md-3">
			    <h4 style="padding:10px;text-align:center;">Organization</h4>
				<p style="padding:10px;text-align:center;">Google Inc.</p>
				<img class="img-responsive" src="img/whoiswho/4c.jpg" alt="main career" style="padding:10px">
		     </div>			 
		  </div>
		 
		<div class="row">
		       <div  class="col-md-12">
			       <h4 class="Bilgraphy" style="text-align:left;">Biography</h4>
				   <p style="text-align:justify;">
				   Sergey Brin is an American computer scientist and internet entrepreneur,
				   who, along with Larry Page, co-founded Google Inc in 1998. Brin migrated to the U.S from
				   the Soviet Union, at a young age. He studied mathematics and computer science in college
				   before going to the Stanford University to pursue a PhD in computer science. As a research
				   scholar, his areas of interests included extraction of information from unstructured sources,
				   search engines, and data mining of large collections of data. He met fellow research scholar
				   Larry page with whom he worked on a research project. The two men connected on the intellectual
				   level and started experimenting with their new designs of search engines in the university
				   computers. Initially, their project was called 'BackRub', and it was funded through the National
				   Science Foundation. Together Brin and Page developed the PageRank algorithm, which is used by
				   Google to rank web pages. The successful running of their project for many months on the
				   University computers convinced the duo to start their own company. They both put their doctoral
				   studies on hold and with financial investment in the form of a $100,000 cheque from Sun
				   Microsystems co-founder, Andy Bechtolsheim, formally incorporated their company, Google Inc, in California.
                   </p>
		       </div>
		    </div>
		<div class="row">
		       <div  class="col-md-12">
			       <h4 class="interview" style="text-align:left;">Interview</h4>
				   <p style="text-align:justify;">  
				   <iframe width="640" height="360" src="https://www.youtube.com/embed/lRRk97FYLJM?rel=0" frameborder="0" allowfullscreen></iframe>
		           </p>
       	    </div>
<div  class="col-md-9">
</div>
<div  class="col-md-3">
<a href="#006" text-align=right>back to top</a>
</div>
		</div>
		
		
		
		<div class="row">
		     <div class="col-md-12">
			     <hr>
				 </div>
		  </div>
		  <div class="row">
		     <div class="col-md-3">
			    <img name="005" id="005" class="img-responsive" src="img/whoiswho/5.jpg" alt="main career" style="padding:10px">
			</div>
			<div class="col-md-3">
			    <h4 style="padding:10px;text-align:center;">Who</h4>
				<h4 style="padding:10px;text-align:center;">Mark Zuckberg</h4>
		    </div>
			<div class="col-md-3">
			    <h4 style="padding:10px;text-align:center;">Title</h4>
				<p style="padding:10px;text-align:center;">CEO of Facebook</p>
		     </div>
            <div class="col-md-3">
			    <h4 style="padding:10px;text-align:center;">Organization</h4>
				<p style="padding:10px;text-align:center;">Facebook, Inc.</p>
				<img class="img-responsive" src="img/whoiswho/5c.jpg" alt="main career" style="padding:10px">
		     </div>			 
		  </div>
		 
		<div class="row">
		       <div  class="col-md-12">
			       <h4 class="Bilgraphy" style="text-align:left;">Biography</h4>
				   <p style="text-align:justify;">
				   Mark Elliot Zuckerberg(born May 14, 1984) is an American computer programmer and Internet entrepreneur.
				   He is best known as one of five co-founders of the social networking website-Facebook.
				   Zuckerberg was made the chairman and chief executive of Facebook, Inc. in April 2013. 
				   and his personal wealth, as of March 2015, is estimated to be $35.1 billion.
				   Mark Zuckerberg receives a one-dollar salary as CEO of Facebook.<br>
                   Together with his college roommates and fellow Harvard University students Eduardo Saverin, Andrew McCollum, 
				   Dustin Moskovitz, and Chris Hughes, Zuckerberg launched Facebook from Harvard University's dormitory rooms. 
				   The group then introduced Facebook onto other campuses nationwide and moved to Palo Alto, California shortly afterwards.
				   In 2007, at the age of 23, Zuckerberg became a billionaire as a result of Facebook's success.
				   The number of Facebook users worldwide reached a total of one billion in 2012. 
				   Zuckerberg was involved in various legal disputes that were initiated by others in the group, 
				   who claimed a share of the company based upon their involvement during the development phase of Facebook.<br>
                   Since 2010, Time magazine has named Zuckerberg among the 100 wealthiest and most influential people
				   in the world as a part of its Person of the Year distinction. In 2011, Zuckerberg ranked first
				   on the list of the "Most Influential Jews in the World" by The Jerusalem Post. Zuckerberg was played by actor 
				   Jesse Eisenberg in the 2010 film The Social Network, in which the rise of Facebook is portrayed.
                   </p>
		       </div>
		    </div>
		<div class="row">
		       <div  class="col-md-12">
			       <h4 class="interview" style="text-align:left;">Interview</h4>
			    <iframe width="640" height="360" src="https://www.youtube.com/embed/DBF1lNygCtw?rel=0" frameborder="0" allowfullscreen></iframe>
       	    </div>
<div  class="col-md-9">
</div>
<div  class="col-md-3">
<a href="#006" text-align=right>back to top</a>
</div>
		</div>	

	    <div class="row">
		     <div class="col-md-12">
			     <hr>
		     </div>
		</div>
		
	
	</div>
	</body>
</html> 

<!-- End page content here-->
<!-- DO NOT EDIT below-->
<?php include("include/footer.php"); ?> 