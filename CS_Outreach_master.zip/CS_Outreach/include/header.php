<!DOCTYPE html>
<html lang="en">
<head>

  <title>CS Outreach Website</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/js/bootstrap.min.js"></script>
</head>
<body>

<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="home.php">CS Outreach Website</a>
    </div>
    <div>
      <ul class="nav navbar-nav">
        <li class="active"><a href="home.php">Home</a></li>
        <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">Student <span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="login_page.php">Sign in</a></li>
            <li><a href="register.php">Register</a></li>
            <li><a href="workshop.php">Workshop</a></li>
          </ul>
        </li>

        <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">Parent <span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="login_page.php">Sign in</a></li>
            <li><a href="register.php">Register</a></li>
	    	<li><a href="permission.php">Permission Form</a></li>
            <li><a href="workshop.php">Workshop</a></li>
          </ul>
        </li>

        <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">Staff <span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="login_page.php">Sign in</a></li>
            <li><a href="register.php">Register</a></li>
            <li><a href="workshop_staff.php">Workshop</a></li>

          </ul>
        </li>

        <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">News <span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="http://today.ttu.edu/">Current News</a></li>
            <li><a href="career.php">What is Computer Science?</a></li>
            <li><a href="whoiswho.php">Who is it?</a></li>
          </ul>
        </li>

        <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">Camps <span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="codingcamp.php">Coding Camp</a></li>
            <li><a href="summercamp.php">Summer Camp</a></li>
            <li><a href="wintercamp.php">Winter Camp</a></li>
          </ul>
        </li>

        <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">Resources <span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="funact.php">Fun Activities</a></li>
            <li><a href="faq.php">FAQ</a></li>
          </ul>
        </li>


      </ul>
    </div>
  </div>
</nav>
  

</body>
</html>
