<!-- Ajeet Yadav, Yongji Li, Elham Hojati -->
<!-- Texas Tech University -->
<!-- CS 5373 -->
<!-- Computer Science Outreach Website -->
<!-- 03/14/15 -->


<!-- footer.php-->
<!-- footer template -->


<html>
<body>

<div class="container">
<div id="footer">
 &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
<a href="http://www.depts.ttu.edu/cs/">Department of Computer Science</a>

 &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp | &nbsp &nbsp &nbsp
<a href="home.php">Home </a><!-- link to homepage-->

 &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp | &nbsp &nbsp &nbsp 
<a href="faq.php">FAQ </a><!-- link to faq-->

&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp| &nbsp &nbsp &nbsp 
<a href="about_us.php">About Us </a><!-- link to about us-->

&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp| &nbsp &nbsp &nbsp 
<a href="contact_us.php">Contact Us</a><!-- link to contact us-->


&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp|&nbsp &nbsp&copy



</body>
</html>

<hr>

<!-- end of footer template-->